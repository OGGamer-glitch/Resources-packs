#version 150
/* 
    WRP (World Resource Pack) shader for lightmap rendering
    Better FullVision
*/

in vec2 texCoord;
out vec4 fragColor;

void main() {
    // 500% Fullbright
    fragColor = vec4(1.0);
}
